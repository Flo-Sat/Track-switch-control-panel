import dash
from dash import html, dcc, Input, Output, State
import i2c_manager
from components import STATE_BTN_DROIT, STATE_BTN_DEVIE


def register_callbacks(app, positions, dashboard_data):

    i2c_manager.init_com(dashboard_data)
    i2c_manager.reset_all(dashboard_data)

    @app.callback(
        [Output(f'img-{aig_id}', 'src')           for aig_id in positions.keys()] +
        [Output(f'state-btn-{aig_id}', 'children') for aig_id in positions.keys()] +
        [Output(f'state-btn-{aig_id}', 'style')    for aig_id in positions.keys()] +
        [Output('aiguillages-state', 'data'),
         Output('output-info', 'children')],
        [Input(f'btn-{aig_id}', 'n_clicks')       for aig_id in positions.keys()] +
        [Input(f'state-btn-{aig_id}', 'n_clicks') for aig_id in positions.keys()],
        State('aiguillages-state', 'data'),
        prevent_initial_call=True
    )
    def update_aiguillages(*args):
        ctx = dash.callback_context
        current_state = args[-1]

        def _btn_children(aig_id):
            label = 'DÉVIÉ' if current_state.get(aig_id, False) else 'DROIT'
            return [
                html.Div(aig_id, style={'font-weight': 'bold', 'font-size': '13px'}),
                html.Div(label,  style={'font-size': '10px', 'margin-top': '4px'})
            ]

        def _build_outputs():
            images      = [f'/assets/{pos["devie"] if current_state[a] else pos["droit"]}.png'
                           for a, pos in positions.items()]
            btn_children = [_btn_children(a) for a in positions.keys()]
            btn_styles   = [STATE_BTN_DEVIE if current_state.get(a, False) else STATE_BTN_DROIT
                            for a in positions.keys()]
            return images, btn_children, btn_styles

        if not ctx.triggered:
            images, btn_children, btn_styles = _build_outputs()
            return images + btn_children + btn_styles + [current_state, ""]

        # Identifier le bouton cliqué (btn- ou state-btn-)
        button_id = ctx.triggered[0]['prop_id'].split('.')[0]
        if button_id.startswith('state-btn-'):
            aiguillage_id = button_id[len('state-btn-'):]
        else:
            aiguillage_id = button_id[len('btn-'):]

        # Inverser l'état
        current_state[aiguillage_id] = not current_state[aiguillage_id]
        devie = current_state[aiguillage_id]

        # Commande I2C
        if aiguillage_id in dashboard_data:
            i2c_addr = int(dashboard_data[aiguillage_id]['i2c'], 16)
            spec     = dashboard_data[aiguillage_id]['spec']
            i2c_manager.pulse(i2c_addr, i2c_manager.OLATB if devie else i2c_manager.OLATA, spec)

        images, btn_children, btn_styles = _build_outputs()
        info = f"Aiguillage {aiguillage_id} → {'dévié' if devie else 'droit'}"

        return images + btn_children + btn_styles + [current_state, info]
