import dash
from dash import html, dcc, Input, Output, State
import dash_bootstrap_components as dbc
import components
import callbacks

# Fonction pour lire les positions depuis le fichier
def read_positions(filename):

    positions = {}
    with open(filename, 'r') as file:
        next(file)
        for line in file:
            data = line.strip().split(';')
            if len(data) == 8:
                aiguillage_id = data[0]
                x = int(data[1])
                y = int(data[2])
                w = int(data[3])
                h = int(data[4])
                droit = data[5]
                devie = data[6]
                table = data[7]
                positions[aiguillage_id] = {'x': x, 'y': y,'w': w, 'h': h , 'droit': droit,'devie': devie, 'table': table}
    return positions

def read_dashboard_data(filename):
    dashboard = {}
    with open(filename, 'r') as file:
        next(file)
        for line in file:
            data = line.strip().split(';')
            if len(data) == 3:
                aiguillage_id = data[0]
                i2c = data[1]
                spec = int(data[2])
                dashboard[aiguillage_id] = {'i2c': i2c, 'spec': spec}

    return dashboard


app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
positions = read_positions('positions.txt')

dashboard_data = read_dashboard_data('positions mapping v2.txt')

if __name__ == '__main__':

    
    app.layout = components.layout(positions,dashboard_data)
    callbacks.register_callbacks(app,positions,dashboard_data)
    app.run(debug=True)
